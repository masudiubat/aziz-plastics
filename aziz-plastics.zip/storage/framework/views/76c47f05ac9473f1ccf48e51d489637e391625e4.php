

<?php $__env->startSection('title', 'Dealers'); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<a href="#" class="kt-subheader__breadcrumbs-link"> Dashboard </a><span class="kt-subheader__breadcrumbs-separator"></span>
<a href="#" class="kt-subheader__breadcrumbs-link"> Dealers </a>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<!-- begin:: Content -->
<div class="kt-container kt-container--fluid kt-grid__item kt-grid__item--fluid">
    <div class="kt-portlet kt-portlet--mobile">
        <div class="kt-portlet__head kt-portlet__head--lg">
            <div class="kt-portlet__head-label">
                <span class="kt-portlet__head-icon">
                    <i class="kt-font-brand flaticon2-line-chart"></i>
                </span>
                <h3 class="kt-portlet__head-title">
                    Dealers
                </h3>
            </div>
            <div class="kt-portlet__head-toolbar">
                <div class="kt-portlet__head-wrapper">
                    <div class="kt-portlet__head-actions">

                        <a href="<?php echo e(route('dealer.create')); ?>" class="btn btn-brand btn-elevate btn-icon-sm">
                            <i class="la la-plus"></i>
                            New Dealer
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="kt-portlet__body">
            <!--begin: Search Form -->
            <div class="kt-form kt-form--label-right kt-margin-t-20 kt-margin-b-10">
                <div class="row align-items-center">
                    <div class="col-xl-8 order-2 order-xl-1">
                        <div class="row align-items-center">
                            <div class="col-md-4 kt-margin-b-20-tablet-and-mobile">
                                <div class="kt-input-icon kt-input-icon--left">
                                    <input type="text" class="form-control" placeholder="Search..." id="generalSearch">
                                    <span class="kt-input-icon__icon kt-input-icon__icon--left">
                                        <span><i class="la la-search"></i></span>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--end: Search Form -->
        </div>
        <div class="kt-portlet__body kt-portlet__body--fit">
            <!--begin: Datatable -->

            <table class="kt-datatable" id="html_table" width="100%">
                <thead>
                    <tr>
                        <!-- <th title="Field #1">Record No</th> -->
                        <th title="Field #1">Company</th>
                        <th title="Field #2">Dealer Name</th>
                        <th title="Field #3">Code</th>
                        <th title="Field #4">Address</th>
                        <th title="Field #5">Phone</th>
                        <th title="Field #6"> Acition </th>
                        <th> &nbsp; </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $dealers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dealer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($dealer->company_name); ?></td>
                        <td><?php echo e($dealer->dealer_name); ?></td>
                        <td><?php echo e($dealer->dealer_code); ?></td>
                        <td><?php echo e($dealer->address); ?></td>
                        <td><?php echo e($dealer->phone); ?></td>
                        <td>
                            <a href="<?php echo e(route('dealer.show', $dealer->id)); ?>" title="Dealer Details" data-placement="top" data-toggle="tooltip" data-original-title="Dealer Details" class="btn btn-xs tooltips btn-success btn-clean">
                                <i class="la la-eye"></i>
                            </a>

                            <a href="<?php echo e(route('dealer.edit', $dealer->id)); ?>" title="Edit" data-placement="top" data-toggle="tooltip" data-original-title="Edit" class="btn btn-xs tooltips btn-clean">
                                <i class="la la-edit"></i>
                            </a>

                            <a href="#" onclick="event.preventDefault(); deleteDealer('<?php echo e($dealer->id); ?>');" title="Delete" data-placement="top" data-toggle="tooltip" data-original-title="Delete" class="btn btn-xs tooltips btn-clean">
                                <i class="la la-trash"></i>
                            </a>
                            <form id="delete-dealer-<?php echo e($dealer->id); ?>" action="<?php echo e(route('dealer.destroy', $dealer->id)); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                            </form>
                        </td>
                        <td> &nbsp; </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <!--end: Datatable -->
        </div>
    </div>
</div>
<!-- end:: Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<!--begin::Page Scripts(used by this page) -->
<script src="<?php echo e(asset('assets/js/pages/crud/metronic-datatable/base/html-table.js')); ?>" type="text/javascript"></script>
<!--end::Page Scripts -->

<script type="text/javascript">
    // Function for delete sub group...
    function deleteDealer(id) {
        const swalWithBootstrapButtons = Swal.mixin({
            customClass: {
                confirmButton: 'btn btn-success',
                cancelButton: 'btn btn-danger'
            },
            buttonsStyling: false
        })

        swalWithBootstrapButtons.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            type: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'No, cancel!',
            reverseButtons: true
        }).then((result) => {
            if (result.value) {
                document.getElementById('delete-dealer-' + id).submit();
            } else if (
                /* Read more about handling dismissals below */
                result.dismiss === Swal.DismissReason.cancel
            ) {
                swalWithBootstrapButtons.fire(
                    'Cancelled',
                    'Your imaginary file is safe :)',
                    'error'
                )
            }
        })
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aziz-plastics\resources\views/pages/dealer/index.blade.php ENDPATH**/ ?>