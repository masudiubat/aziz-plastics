<script>
    var KTAppOptions = {
        "colors": {
            "state": {
                "brand": "#5d78ff",
                "dark": "#282a3c",
                "light": "#ffffff",
                "primary": "#5867dd",
                "success": "#34bfa3",
                "info": "#36a3f7",
                "warning": "#ffb822",
                "danger": "#fd3995"
            },
            "base": {
                "label": [
                    "#c5cbe3",
                    "#a1a8c3",
                    "#3d4465",
                    "#3e4466"
                ],
                "shape": [
                    "#f0f3ff",
                    "#d9dffa",
                    "#afb4d4",
                    "#646c9a"
                ]
            }
        }
    };
</script>
<!-- end::Global Config -->

<!--begin::Global Theme Bundle(used by all pages) -->
<script src="<?php echo e(asset('assets/plugins/global/plugins.bundle.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('assets/js/scripts.bundle.js')); ?>" type="text/javascript"></script>
<!--end::Global Theme Bundle -->

<!--end::Page Scripts -->
<script src="<?php echo e(asset('assets/js/toastr.min.js')); ?>"></script>

<?php echo Toastr::message(); ?>


<script>
    <?php if($errors -> any()): ?>
    <?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    toastr.error('<?php echo e($error); ?>', 'Error', {
        "closeButton": true,
        "progressBar": true
    });
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</script>

<?php echo $__env->yieldPushContent('js'); ?><?php /**PATH C:\xampp\htdocs\aziz-plastics\resources\views/partials/default-js.blade.php ENDPATH**/ ?>